import sys
import subprocess
import json
import time
import random
import os
import datetime
import xml.dom.minidom

def getCppcheckPath( tool_path ):
    setting_file = os.path.join( tool_path, "setting.json")
    with open(setting_file) as in_file:
        data = json.load( in_file )
        return data['cpp_check_path']

def createTmpFileName( source_path ):
    fileName = "cppcheck_%s_%s.txt" % ( os.path.split(source_path)[1], datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
    return os.path.join( os.environ['TMP'], fileName )
        


def clearNoise( fileName ):
    dom = xml.dom.minidom.parse(fileName)
    root = dom.documentElement
    errors = root.getElementsByTagName('error')

    SCA_ERROR_MSG = 'has a constructor with 1 argument that is not explicit'
    
    count = 0
    for error in errors:
        msg = error.getAttribute('msg')
        if SCA_ERROR_MSG in msg:
            continue
        location = error.getElementsByTagName('location')[0]
        print location.getAttribute('file'),':',location.getAttribute('line'),"  ",msg
        count += 1

    if not count:
        print "No Warning"    

def getSourceFolder( proj_folder ):
    path_lists = os.path.split( proj_folder )
    if path_lists[1] == "...":
        return path_lists[0]
    else:
        return proj_folder

def docppcheck( tool_path, proj_folder ):
    cppcheck_path = getCppcheckPath( tool_path )
    if not os.path.exists( cppcheck_path ):
        print "Can't find cppcheck.exe at ",cppcheck_path
        return

    souce_folder = getSourceFolder( proj_folder )
    if not os.path.exists( souce_folder ):
        print "Can't find the source code folder at ",souce_folder
        return

    #tmp_file = createTmpFileName( souce_folder )
    command = '''"{cpp_check_path}" -q --enable=style  "{proj_path}" '''.format( cpp_check_path = cppcheck_path, proj_path = souce_folder )
    subprocess.call( command , shell = True )



if __name__ == '__main__':
    tool_path = sys.argv[1]
    proj_folder = sys.argv[2]
    print '-'*50
    print "Check ",proj_folder
    print '-'*50
    docppcheck( tool_path, proj_folder )
    print '-'*50
    print "Command Done!"
    print '-'*50    