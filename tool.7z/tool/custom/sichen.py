
#========= expand the go command here ==================================
#========= the foramt is def go_xxx( params ): ...., then you can call tool go xxx to visit there
def go_chensitan( params ):
	import os
	os.system(r"start explorer \\apchnfs05\Depts\PD\MSC\Graphics\cst")

def go_bugs( params ):
	import os
	os.system(r"start explorer  G:\bugs")

def go_dailyreport( params ):
	def getYearMonthStr():
		import time
		datetime = time.localtime()
		return "{year}.{month:02}".format( year = datetime.tm_year, month = datetime.tm_mon)

	daily_report_path = r"\\apchnfs05\Depts\PD\MSC\Graphics\dailyreport\{0}".format(getYearMonthStr())
	import os
	if os.path.exists(daily_report_path):
		os.system("start explorer {0}".format(daily_report_path) )
	elif os.path.exists(r"\\apchnfs05\Depts\PD\MSC\Graphics\dailyreport"):
		os.system(r"mkdir {0}".format(daily_report_path))
		os.system("start explorer {0}".format(daily_report_path) )
	else:
		print( "ErrorPath:"+daily_report_path)


#========================put custom command here ==============================
#the format is def xxx( params ): ..., then you can call tool xxx ... to execute your command 
def hehe( params ):
	print("Just a example, params:"),
	print( params)

