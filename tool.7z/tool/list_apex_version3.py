import os
import sys
import traceback

class VersionList( object ):
	def __init__( self, installer_root, bbt_root , local_root):
		self._installer_root = installer_root
		self._bbt_root = bbt_root
		self._local_root = local_root
		self._targetCLs = []
		self._allCLs = []

	def _getColdeLine( self ):
		return self._installer_root.split('\\')[-1]

	def _getLastestCL( self ):
		versions = [int(each_version_str) for each_version_str in os.listdir(self._installer_root) if each_version_str.isdigit() ]
		versions.sort(reverse=True)
		return versions


	def _getInstallerInfo(self, clNum):
		data = dict()
		data['clNum'] = clNum
		data['isBBTExist'] = "" if self._isBBTExist(clNum) else "Missing"
		data['isTestsExist'] = "" if self._isTestsExist(clNum) else "Missing"
		data['isLocalExist'] = "Has" if self._isLocalExist(clNum) else ""
		data['fileSize'] = self._getInstallerSize(clNum)
		return data

	def _isBBTExist( self, clNum ):
		return os.path.exists( os.path.join(self._bbt_root,str(clNum)) )

	def _isTestsExist( self, clNum ):
		return os.path.exists( os.path.join(self._installer_root,str(clNum),"cl{0}-vtune-tests.7z".format(clNum)))


	def _isLocalExist( self, clNum ):
		return os.path.exists( os.path.join(self._local_root,str(clNum)) )

	def _getInstallerSize(  self, clNum ):
		try:
			fileName= os.path.join(self._installer_root,str(clNum),"cl{0}-vtune.7z".format(clNum) )
			size_value = os.path.getsize( fileName )
		except:
			size_value = 0
		return "%0.1fG" % (size_value/1024.0/1024.0/1024.0)

	def displayVersionInfo( self, count ):
		self._allCLs = self._getLastestCL()
		self._targetCLs = self._allCLs[0:count]
		print('')
		print('*'*30)
		print('%s latest mods:' % self._getColdeLine())
		print('*'*30)
		print('')
		print("{0:<10} {1:<10} {2:<10} {3:<15} {4:10}".format("INDEX","CL","SIZE", "TESTS Folder","ALREADY_HAS"))
		print("")
		index = 0
		for each_cl in self._targetCLs:
			data = self._getInstallerInfo( each_cl )
			print("  {0:<8} {1:<10} {2:<10} {3:<15} {4:10}".format( index,data['clNum'],data['fileSize'],  data['isTestsExist'] , data['isLocalExist']) )
			index+=1
		print("")

	def getTargetCLCount( self ):
		return len( self._targetCLs )

	def chooseCL( self, index_str ):
		try:
			index = int(index_str)

			if index in self._allCLs:
				return index

			if 0 <= index < len( self._targetCLs ):
				return self._targetCLs[index]
			else:
				return 0
		except:
			return 0


def main( installer_root, bbt_root , local_root ):
	v = VersionList(installer_root, bbt_root , local_root )
	v.displayVersionInfo(30)
	clCount = v.getTargetCLCount()
	index_str = input("Please input the index [0-{0}] or CL number:".format(clCount-1) )
	sys.exit(v.chooseCL(index_str))

if __name__ == '__main__':
	try:
		installer_root = sys.argv[1]
		bbt_root = sys.argv[2]
		local_root = sys.argv[3]
		main(installer_root, bbt_root ,local_root)
	except Exception :
		traceback.print_exc()
		sys.exit(0)