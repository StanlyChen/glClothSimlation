#-*- coding:utf-8 -*-

import os
import sys
import re
import subprocess
import time
import importlib

#config
APEX_REMOTE_REPOSITORY = r"\\rbcview"
TOOL_FOLDER=r"\\apchnfs05\Depts\PD\MSC\Graphics\cst\tool"

#-------------------------

#make this script to run both on 2.x and 3.x
real_raw_input = vars(__builtins__).get('raw_input',input)

def getLocalApexPathFromCL( cl ):
	target_path = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"),
	os.environ.get("CODELINE", "undefine CODELINE"), 
	"{0}".format(cl),"cl{0}".format(cl))
	return target_path

def displayLocalCLList():
	apex_folder = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"),
	os.environ.get("CODELINE", "undefine CODELINE") )

	if not os.path.exists( apex_folder ):
		print ("Invalid  path: {0}".format(apex_folder))
		return
	else:
		local_versions = [ int( cl ) for cl in os.listdir(apex_folder) if cl.isdigit()]
		print("\nLocal CLs:")
		print("-"*10)
		if len( local_versions ):
			for each in local_versions:
				print(each)
			print("-"*10)
			print("Current:"),
			displayCurrentLinkSource()
		else:
			print("NONE!")
		print("-"*10)

def getLocalHeadCL():
	apex_folder = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"), 
	os.environ.get("CODELINE", "undefine CODELINE") )
	if not os.path.exists( apex_folder ):
		raise ValueError("Invalid  path: {0}".format(apex_folder))
	local_versions = [ int( cl ) for cl in os.listdir(apex_folder) if cl.isdigit()]
	return max(local_versions)

def getLocalApexPathForInput(input_str):
	if input_str.isdigit():
		cl = int(input_str)
		target_path = getLocalApexPathFromCL(cl)
	else:
		if input_str.lower() == "head":
			cl = getLocalHeadCL()
			target_path = getLocalApexPathFromCL(cl)
		else:
			target_path = input_str
	return target_path

def createVersionListInstance():
	codeLine = os.environ.get("CODELINE", None)
	if not codeLine:
		codeLine = os.environ.get("CODELINE", None)
	if not codeLine:
		print("Undefine CodeLine")
		return None
	installer_root = r"{0}\Devl\builds\predator\installers\{1}".format(APEX_REMOTE_REPOSITORY,codeLine)
	bbt_root = r"{0}\Devl\builds\predator\BBT\{1}".format(APEX_REMOTE_REPOSITORY,codeLine)
	local_root = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"),codeLine)
	from list_apex_version3 import VersionList
	vl = VersionList(installer_root,bbt_root,local_root)
	return vl

def getCurrentModPath():
	proc = subprocess.Popen('''dir %VARIANT_DIR%\mod | findstr "apex"''', stdout=subprocess.PIPE, shell = True)
	tmp = proc.stdout.read()
	if tmp:
		#11/06/2017  01:14 PM    <JUNCTION>     Framework [D:\download\DEV_D1\526045\cl526045\Framework]
		#06/05/2018  10:59 AM    <JUNCTION>     apex [D:\cst\download\DEV_D2_PROJ_O\573308\cl573308\apex]
		return re.findall("\[(.*)(apex\])",tmp)[0][0]
	else:
		return None

def getLocalCLList():
	apex_folder = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"), 
	os.environ.get("CODELINE", "undefine CODELINE") )

	if not os.path.exists( apex_folder ):
		print ("Invalid  path: {0}".format(apex_folder))
		return None
	else:
		local_versions = [ int( cl ) for cl in os.listdir(apex_folder) if cl.isdigit()]
		return local_versions


def getFilePathInMod( apex_folder, _compName):
	ret = []
	if _compName.lower() == "ddm":
		compName ="Display3DDataManager"
	else:
		compName = _compName


	for root, folders,files in os.walk(apex_folder):
		for folder in folders:
			if folder.lower() == compName.lower():
				fullpath = os.path.join( root, folder )
				ret.append( os.path.relpath( fullpath, apex_folder ) )
	return ret


#-------------------------------------

def linkws( params ):
	if len(params):
		target_path = getLocalApexPathForInput(params[0])
	elif len(params) == 0:
		displayLocalCLList()
		input_str = real_raw_input("Input the cl num or path: ")
		target_path = getLocalApexPathForInput(input_str)

	if not os.path.exists( target_path ):
		print ("Invalid  path: {0}".format(target_path))
		return
	else:
		os.system(r"call {0}\linkws.bat %VARIANT_DIR%\mod {1}".format(TOOL_FOLDER,target_path))



def listapex( params ):
	list_count = 10
	if len(params) and params[0].isdigit():
		list_count = int( params[0] )
	
	vl = createVersionListInstance()
	if vl:
		vl.displayVersionInfo( list_count )

def listlocalapex( params ):
	displayLocalCLList()

def backup( params ):
	def backupImpl(run_time_name):
		import os
		app = os.environ.get( run_time_name , None)
		if not app or not os.path.exists(app):
			print("cannot find " + run_time_name )
			return
		app_backup = app+"0"
		if os.path.exists( app_backup ):
			print( app_backup +" already exists")
			return
		os.system( "robocopy {src} {target} >nul".format( src = app, target = app_backup ) )
		
	for param in params:
		run_time_name = param.upper()+"_RUNTIME"
		backupImpl( run_time_name )	

def downloadApex( params ):
	if "pdb" in params:
		unzip_pdb = True
	else:
		unzip_pdb = real_raw_input('Do you need PDB files?    no(default) | yes :').lower() == "yes"

	if "notest" in params:
		getTest = False
	else:
		getTest = real_raw_input("Do you need tests folder?   yes(default) | no:").lower() != "no" 


	#cl num
	cls = [ cl for word in params for cl in re.findall("^[0-9]{6}$", word) ]
	if len(cls) != 0:
		cl = cls[0]
	else:
		vl = createVersionListInstance()
		vl.displayVersionInfo(10)
		clCount = vl.getTargetCLCount()
		index_str = real_raw_input("Please input the index [0-{0}] or CL number:".format(clCount-1) )
		cl = vl.chooseCL( index_str)
		
	os.system(r"call {tool_folder}\install_apex_service3.bat {CL} {UNZIP_PDB} {GET_TEST_FOLDER} {APEX_REMOTE_REPOSITORY}".format(
		tool_folder =TOOL_FOLDER, CL= cl, 
		UNZIP_PDB = "yes" if unzip_pdb else "no",
		GET_TEST_FOLDER  = "yes" if getTest else "no",
		APEX_REMOTE_REPOSITORY = APEX_REMOTE_REPOSITORY ))

def displayCurrentLinkSource( params = None):
	path = getCurrentModPath()
	if path:
		print(path)
	else:
		print("Can't found version info")
		
def deleteLocalApex( params ):
	apex_folder = os.path.join( os.environ.get("ApexDownloadFolder","undefine ApexDownloadFolder"),
	os.environ.get("CODELINE", "undefine CODELINE") )
	local_versions = getLocalCLList()
	if not local_versions:
		return
	removeSet = { cl for cl in local_versions }
	if len(params) == 1 and params[0] == "all":
		pass
	elif len(params) == 2 and params[0].lower() == "allbut" and params[1].isdigit():
		cl = int(params[1])
		if cl in removeSet:
			removeSet.remove(cl)
		else:
			print("CL{0} doesn't exists.".format(cl))
			return
	else:
		removeSet = {int(cl) for cl in params if cl.isdigit() and int(cl) in local_versions }

	if len(removeSet) == 0:
		print("No valid CL number.")
		return
	else:
		print("We are about to remove {0}".format(removeSet))

	os.system("pause")

	for cl in removeSet:
		target_cl = os.path.join( apex_folder, str(cl))
		cmd = '''powershell -Command "Remove-Item '{0}' -Recurse -Force"'''.format(target_cl)
		print("-"*20)
		print("Removing {0}".format(target_cl))
		os.system(cmd)

def go( params , custom_handle):
	if len(params) == 1:
		if params[0].lower() == ".":
			os.system("start explorer .")
			return
		elif params[0].lower() == "mod":
			path = getCurrentModPath()
			if path:
				os.system("start explorer {0}".format(path))
			else:
				print("No mod path")
			return
		elif params[0].lower() == "remote":
			os.system(r"start explorer {0}\Devl\builds\predator\installers".format(APEX_REMOTE_REPOSITORY))
			return
		elif params[0].lower() == "download":
			os.system("start explorer %ApexDownloadFolder%\\%CodeLine%")
			return
		elif re.search("^xx[0-9]+$",params[0]):
			os.system("start explorer https://jira.mscsoftware.com/browse/XX-{0}".format(params[0][2:]))

		elif params[0].lower() == "build_server":
			os.system("start explorer {0}".format(APEX_REMOTE_REPOSITORY))
		elif params[0].lower() == "out":
			os.system(r"start explorer %VARIANT_DIR%")
		else:
			custom_function = getattr( custom_handle, "go_{0}".format(params[0]), None)
			if custom_function:
				custom_function( params )
			else:		
				os.system("start explorer {0}".format(params[0]))

def unzippdb( params ):
	if len(params) == 0 or not params[0].isdigit():
		print("CL num is needed")
		return
	local_list = getLocalCLList()
	if not local_list:
		return

	cl = int( params[0])
	if cl not in local_list:
		print("Invalid CL num")
		return

	ow_mode = "-aos" #overwrite mode
	filters = "-ir!*.pdb "

	if len(params) == 1:
		os.system(r"call {tool_folder}\unzippdb.bat {CL} {OW_MODE} {FILTER} ".format(tool_folder=TOOL_FOLDER,CL=cl,OW_MODE=ow_mode,FILTER=filters))
	else:
		apex_folder =  getLocalApexPathFromCL( cl )		
		for comp in params[1:]:
			paths = getFilePathInMod( apex_folder, comp )
			if paths:
				for path in paths:
					path = "cl{0}\\{1}".format(cl,path)
					ow_mode=""
					filters = "-ir!{0}\\*.pdb".format(path)
					os.system(r"call {tool_folder}\unzippdb.bat {CL} {OW_MODE} {FILTER} ".format(tool_folder=TOOL_FOLDER,CL=cl,OW_MODE=ow_mode,FILTER=filters))
			else:
				print("Can't find anything about {0}".format(comp))


def type_error( params ):
	log_folder = os.path.join( sys.argv[1], "sand_logs")
	for filename in reversed( os.listdir( log_folder) ):
		if filename.endswith("problems.log"):
			full_name = os.path.join( log_folder, filename )
			print full_name
			os.system("type {0}".format( full_name ) )
			return


def type_log( params ):
	log_folder = os.path.join( sys.argv[1], "sand_logs")
	print(log_folder)
	for filename in reversed( os.listdir( log_folder) ):
		if filename.endswith("output.log"):
			os.system("start notepad {0}".format( os.path.join( log_folder, filename )) )
			return

def displayHelp( params ):
	usage = [] 
	usage.append("commands usage:")
	usage.append("tool help")
	usage.append("tool linkws [CL | PATH]")
	usage.append("tool list [COUNT]")
	usage.append("tool listlocal")
	usage.append("tool download [pdb] [notest] [cl]")
	usage.append("tool current")
	usage.append("tool delete CL | CL CL ...| all |allbut CL")
	usage.append("tool pdb CL")
	usage.append("tool backup component_name")
	usage.append("tool go .|mod|TARGET")
	usage.append("tool error")
	usage.append("tool log")
	print("\n\t".join(usage))
#----------------------------------------------------------------------
def main():
	custom_handle = None
	expand_script = os.environ.get("expand", "sichen")
	if expand_script:
		custom_module = "custom."+expand_script
		try:
			custom_handle = importlib.import_module( custom_module)
		except:
			raise

	if len( sys.argv ) < 3:
		displayHelp(None)
		return


	codeLine = os.environ.get("CODELINE", None)
	if codeLine == "DEV_D1":
		print("*******************************")
		print('''News: D1 is supported now. Replace "tool" with "tool_d1" in the last line of tool.bat.\nExmaple:...\cst\\tool_d1\main.py %~dp0 %*''')
		print("*******************************")
		print("")
		print("")

	working_dir =sys.argv[1]
	command = sys.argv[2]
	params = sys.argv[3:]
	if command.lower() == "help" or command.lower() == "-h" or command.lower() == r'/?':
		return displayHelp(params)
	if command.lower() == "linkws":
		return linkws(params)
	elif command.lower() == "list":
		return listapex( params )
	elif command.lower() == "listlocal":
		return listlocalapex(params)
	elif command.lower() == "download":
		return downloadApex(params)
	elif command.lower() == "current":
		return displayCurrentLinkSource(params)
	elif command.lower() == "delete":
		return deleteLocalApex( params )
	elif command.lower() == "go":
		return go(params, custom_handle)
	elif command.lower() == "pdb":
		return unzippdb(params)
	elif command.lower() == "backup":
		return backup( params )
	elif command.lower() == "error":
		return type_error(params)
	elif command.lower() == "log":
		return type_log(params)
	else:
		custom_function = getattr( custom_handle, command.lower(), None )
		if custom_function:
			custom_function( params )
		else:
			print("unknow command : {0}".format(command))
			print("")
			return displayHelp(params)

if __name__ == '__main__':
	main()

