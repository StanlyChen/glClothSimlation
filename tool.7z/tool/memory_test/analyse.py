import sys
sys.dont_write_bytecode = True

import csv
import os

FILE_LINE_RESULT_QUALITY_BEST = 3
FILE_LINE_RESULT_QUALITY_NORMAL = 2
FILE_LINE_RESULT_QUALITY_BAD = 1
FILE_LINE_RESULT_QUALITY_NONE = 0



AVERAGE_UNIT = "B"

class Config( object ):
	def __init__( self , base, unit):
		self._base = base   # 10 or 16
		self._unit = unit.upper()   # "G" or "M" or "K" or "B"

	def base( self ):
		return self._base

	def number_in_unit( self , number_in_byte, _unit = None):
		unit = _unit or self._unit 
		if  unit == 'G':
			return number_in_byte/1024.0/1024.0/1024.0
		elif  unit == 'M':
			return number_in_byte/1024.0/1024.0
		elif  unit == 'K':
			return number_in_byte/1024.0
		else:
			return number_in_byte

	def unit( self,  _unit = None ):
		unit = _unit or self._unit 
		if  unit == 'G':
			return "(Gb)"
		elif  unit == 'M':
			return "(Mb)"
		elif  unit == 'K':
			return "(Kb)"
		else:
			return "(Byte)"

class Traceback( object ):
	def __init__( self, lines, app_dlls, config ):
		self._config = config
		self._lines = lines
		self._belongAppDll = "@system"

		self._belongFileLine= ""
		self._parseLines( app_dlls )

	def _parseLines( self , app_dlls):
		first_line = self._lines[0].split()		
		second_line = self._lines[1].split()
		self._totalsize = int(first_line[1],self._config.base()) * ( 1 if first_line[0] == '+' else -1)
		self._count = int(second_line[1],self._config.base())

		self._size_logA = int( first_line[3],self._config.base())
		self._size_logB = int( first_line[5][:-1],self._config.base())
		self._count_logA = int( second_line[3],self._config.base())
		self._count_logB = int( second_line[5][:-1],self._config.base())

		belongDll = None
		belongFileLine = None
		belongFileLineResultQuality = FILE_LINE_RESULT_QUALITY_NONE

		for i in range( 2 , len(self._lines) ):
			split_idx = self._lines[i].index('!');
			dllName = self._lines[i][:split_idx]
			symbol = self._lines[i][split_idx+1:]
			if belongDll :
				if dllName != belongDll:
					break
				else:
					if '(' in symbol:
						fileLine = self._geFileLine(symbol)
						fileLineResultQuality = self.getFileLineResultQuality(fileLine)
					else:
						fileLine = symbol
						fileLineResultQuality = FILE_LINE_RESULT_QUALITY_NORMAL

					if fileLineResultQuality > belongFileLineResultQuality:
						belongFileLine = fileLine
						belongFileLineResultQuality = fileLineResultQuality

					if belongFileLineResultQuality == FILE_LINE_RESULT_QUALITY_BEST:
						break;
			else:
				if dllName not in app_dlls:
					continue
				else:
					if '(' in symbol:
						fileLine = self._geFileLine(symbol)
						fileLineResultQuality = self.getFileLineResultQuality(fileLine)
					else:
						fileLine = symbol
						fileLineResultQuality = FILE_LINE_RESULT_QUALITY_NORMAL

					if fileLineResultQuality > belongFileLineResultQuality:
						belongDll = dllName
						belongFileLine = fileLine
						belongFileLineResultQuality = fileLineResultQuality

					if belongFileLineResultQuality == FILE_LINE_RESULT_QUALITY_BEST:
						break;
						
		if belongDll is not None:
			self._belongAppDll = belongDll

		if belongFileLine is not None:
			self._belongFileLine = belongFileLine

	def _geFileLine( self, line ):
		start_idx = line.index('(')+1
		end_idx = line.index(')')
		return line[start_idx:end_idx]

	def getFileLineResultQuality( self, fileLine):
		for key_world in ["plugins",'services',"gfx","eommain"]:
			if key_world in fileLine.split('\\'):
				return FILE_LINE_RESULT_QUALITY_BEST
		return FILE_LINE_RESULT_QUALITY_BAD

	def getBelongAppDll( self ):
		return self._belongAppDll

	def getSize(self):
		return self._totalsize

	def getSizeLogA(self):
		return self._size_logA

	def getSizeLogB( self ):
		return self._size_logB


	def getCountLogA( self ):
		return self._count_logA

	def getCountLogB( self ):
		return self._count_logB

	def getCount( self ):
		return self._count

	def getCallStack( self ):
		return '\n'.join( self._lines[2:])

	def getLine( self ):
		return self._belongFileLine

class PARSE_STATE(object):
	ENUM_DLL = 1
	ENUM_TRACEBACK = 2

class Analyse( object ):
	def __init__( self, source_file, config ):
		self._config = config
		self._source_file = source_file
		self._getOutputFolder()

		self._sys_dll = []
		self._app_dll = []
		self._dll_path = dict()

		self._tracebacks = []


	def _getOutputFolder( self ):
		if '.' in self._source_file:
			idx = self._source_file.rindex('.')
			self._output_folder = self._source_file[:idx] + "_output"
		else:
			self._output_folder = "_output"


	def getOutputFolder( self ):
		return self._output_folder

	def _touchOutputDir( self ):
		if not os.path.exists( self._output_folder):
			os.mkdir(  self._output_folder )

	def getTotalLineNumber( self ):
		with open( self._source_file , 'rb') as f:
			line_count = 0
			while True:
				buffer = f.read(812*1024);
				if not buffer:
					break
				line_count += buffer.count('\n')
			return line_count


	def parseFile( self ):
		def getDllName( line ):
			return line.split()[2]

		print "Counting the length of the file..."
		totalLineNum = self.getTotalLineNumber()

		print "Loading the file..."
		with open( self._source_file ) as f:
			parse_state = PARSE_STATE.ENUM_DLL
			cur_traceback_lines=[]

			progress_report_line = totalLineNum/100 
			cur_progress = 0
			for line in f:

				progress_report_line -= 1
				if progress_report_line == 0:
					cur_progress += 1
					print "Progress: %d%%" % cur_progress
					progress_report_line = totalLineNum/100 

				line = line.lstrip().rstrip()
				if not line:
					continue
				if parse_state == PARSE_STATE.ENUM_DLL:
					if line.startswith( "// Each log entry has the following syntax:" ):
						tmp_app_dll_list = []
						for dllname in self._app_dll:
							if self._isBasicAppDLL( dllname ):
								self._sys_dll.append( dllname)
							else:
								tmp_app_dll_list.append( dllname )
						self._app_dll = tmp_app_dll_list
						parse_state = PARSE_STATE.ENUM_TRACEBACK
					elif "export symbols" in line:
						self._sys_dll.append( getDllName(line) )
					elif "private symbols & lines" in line:
						dllName = getDllName(line)
						self._app_dll.append( dllName )
					elif line.endswith('.pdb'):
						dllName = line.split('\\')[-1][:-4]
						self._dll_path[dllName] =  line
				elif parse_state == PARSE_STATE.ENUM_TRACEBACK:
					if line.startswith("//"):
						continue
					if line.startswith("Total increase =="):
						if cur_traceback_lines:
							self._tracebacks.append( Traceback(cur_traceback_lines, self._app_dll, self._config) )
							cur_traceback_lines = []
						break
					elif ( line.startswith('+') or line.startswith('-') ) and line.split()[-1].startswith("BackTrace"):
						if cur_traceback_lines:
							self._tracebacks.append( Traceback(cur_traceback_lines, self._app_dll, self._config) )
							cur_traceback_lines = []
						cur_traceback_lines.append( line )
					else:
						cur_traceback_lines.append( line )




	def listDlls( self ):
		self._touchOutputDir()
		csvfile = file( os.path.join( self._output_folder, "Apex_Dlls.csv" ), 'wb')
		writer = csv.writer(csvfile)
		writer.writerow(['Dll', 'TYPE', 'PATH'])

		print("SYS_DLL:")
		for dllName in self._sys_dll:
			print(dllName + "      " + self._dll_path.get(dllName,"") )
			writer.writerow( (dllName+'.dll', 'SYSTEM', self._dll_path.get(dllName,"")) )

		print("#"*30)
		print("\n")
		print("\n")
		print("App_DLL:")
		for dllName in self._app_dll:
			print(dllName + "      " +self._dll_path.get(dllName,"") )
			writer.writerow( (dllName+'.dll', 'APPLICATION', self._dll_path.get(dllName,"")) )


	def _isBasicAppDLL( self , dllName ):
		dllPath = self._dll_path[dllName]
		if 'scasystem' in dllPath:
			return True
		elif dllName in ["Results_6_0"]:
			return True
		else:
			return False

	def query( self, dllName ):
		tmp_traceback = [ each  for each in self._tracebacks if each.getBelongAppDll() == dllName ]
		
		detal_usage= 0
		usage_logA = 0
		usage_logB = 0
		for traceback in tmp_traceback:
			detal_usage += traceback.getSize() 
			usage_logA += traceback.getSizeLogA()
			usage_logB += traceback.getSizeLogB()

		data = {}
		data['name'] = dllName+'.dll'
		data['delta_usage'] = detal_usage
		data['usage_logA'] = usage_logA
		data['usage_logB'] = usage_logB
		return data

	def printDll( self , dllName ):
		tmp_tracebacks = [ each  for each in self._tracebacks if each.getBelongAppDll() == dllName]
		total_delta_usage = sum( [ each.getSize() for each in tmp_tracebacks ] )

		print '#'*30
		print dllName,".dll"
		print "Total Tracebacks:",len(tmp_tracebacks)
		print 'Total Detla Usage'+ self._config.unit(), self._config.number_in_unit(total_delta_usage)
		print "\n"

		self._touchOutputDir()
		csvfile = file( os.path.join( self._output_folder, dllName+'_by_callstack.csv'), 'wb')
		writer = csv.writer(csvfile)

		writer.writerow(('Traceback Count',"Total Delta Usage"+ self._config.unit())  )
		writer.writerow( (len(tmp_tracebacks), self._config.number_in_unit(total_delta_usage)) )
		writer.writerow([])
		writer.writerow([])

		writer.writerow(('Delta Usage'+self._config.unit(),"Delta Count","DeltaUsage/DeltaCount"+self._config.unit(AVERAGE_UNIT),"UsageLogA"+self._config.unit(),"UsageLogB"+self._config.unit(),"CountLogA","CountLogB","UsageLogA/CountLogA"+self._config.unit(AVERAGE_UNIT),"UsageLogB/ContLogB"+self._config.unit(AVERAGE_UNIT),'CallStack'))
		for traceback in tmp_tracebacks:
			#print 'Usage',traceback.getSize()
			#print "Stack"
			#print "\n"
			stack = traceback.getCallStack()
			delta_count = traceback.getCount()
			delta_usage = traceback.getSize()
			usage_logA = traceback.getSizeLogA()
			usage_logB = traceback.getSizeLogB()
			count_logA = traceback.getCountLogA()
			count_logB = traceback.getCountLogB()
			usage_per_count_delta = (delta_usage / delta_usage) if delta_usage != 0 else 0
			usage_per_count_logA = (usage_logA / count_logA) if count_logA != 0 else 0
			usage_per_count_logB =(usage_logB / count_logB) if count_logB != 0 else 0
			#print stack
			#print "\n"*3
			writer.writerow((
				self._config.number_in_unit( delta_usage ), 
				delta_count,
				self._config.number_in_unit( usage_per_count_delta, AVERAGE_UNIT ), 
				self._config.number_in_unit( usage_logA ), 
				self._config.number_in_unit( usage_logB ), 
				count_logA,
				count_logB,
				self._config.number_in_unit( usage_per_count_logA, AVERAGE_UNIT ), 
				self._config.number_in_unit( usage_per_count_logB, AVERAGE_UNIT), 
				stack) ); 

		csvfile.close()
		
	def printDllByLine( self ,dllName):
		tmp_tracebacks = [ each  for each in self._tracebacks if each.getBelongAppDll() == dllName]
		total_delta_usage = sum( [ each.getSize() for each in tmp_tracebacks ] )

		print '#'*30
		print dllName,".dll"
		print "Total Tracebacks:",len(tmp_tracebacks)
		print 'Total Delta Usage'+ self._config.unit(), self._config.number_in_unit(total_delta_usage)
		print "\n"

		self._touchOutputDir()
		csvfile = file( os.path.join( self._output_folder, dllName+'_by_line.csv'), 'wb')
		writer = csv.writer(csvfile)

		writer.writerow(('Traceback Count',"Total Delta Usage"+ self._config.unit())  )
		writer.writerow( (len(tmp_tracebacks), self._config.number_in_unit(total_delta_usage)) )
		writer.writerow([])
		writer.writerow([])

		writer.writerow(['File&Line', 'Delta Usage'+self._config.unit(),"Delta Count","DeltaUsage/DeltaCount"+self._config.unit(AVERAGE_UNIT),"UsageLogA","UsageLogB","CountLogA","CountLogB","UsageLogA/CountLogA"+self._config.unit(AVERAGE_UNIT),"UsageLogB/ContLogB"+self._config.unit(AVERAGE_UNIT)])

		line_info_data = dict()
		for traceback in tmp_tracebacks:
			line = traceback.getLine()
			if line:
				if line not in line_info_data:
					line_info_data[line] = []
				line_info_data[line].append( traceback )

		for line in line_info_data:
			usage_delta = 0;

			count_delta = 0
			usage_logA = 0
			usage_logB = 0
			count_logA = 0
			count_logB = 0
			for traceback in line_info_data[line]:
				usage_delta += traceback.getSize()
				count_delta += traceback.getCount()
				usage_logA += traceback.getSizeLogA()
				usage_logB += traceback.getSizeLogB()
				count_logA += traceback.getCountLogA()
				count_logB += traceback.getCountLogB()

			usage_per_count_delta = (usage_delta / count_delta) if count_delta != 0 else 0
			usage_per_count_logA = (usage_logA / count_logA) if count_logA != 0 else 0
			usage_per_count_logB =(usage_logB / count_logB) if count_logB != 0 else 0
			print '-'*30
			print "Line: ", line

			print 'Delta Usage: ', self._config.number_in_unit(usage_delta)
			print "UsageLogA: ", self._config.number_in_unit(usage_logA)
			print "UsageLogB: ", self._config.number_in_unit(usage_logB)
			print "DeltaCount: ", count_delta
			print "CountLogA: ", self._config.number_in_unit(count_logA)
			print "CountLogB: ", self._config.number_in_unit(count_logB)
			print "DeltaUsage/DeltaCount: ", self._config.number_in_unit(usage_per_count_delta)
			print '\n'
			writer.writerow((
				line,
				self._config.number_in_unit(usage_delta),
				count_delta,
				self._config.number_in_unit(usage_per_count_delta,AVERAGE_UNIT),
				self._config.number_in_unit(usage_logA),
				self._config.number_in_unit(usage_logB),
				count_logA,
				count_logB,
				self._config.number_in_unit( usage_per_count_logA ,AVERAGE_UNIT), 
				self._config.number_in_unit( usage_per_count_logB ,AVERAGE_UNIT)
				));

		csvfile.close()



	def queryAll( self ):
		results = []
		dlls =  ['@system']
		dlls.extend(self._app_dll)
		print "All Application Dlls:"
		print dlls
		print '\n'
		print '\n'
		print '\n'

		self._touchOutputDir()
		csvfile = file( os.path.join( self._output_folder, "Apex_Dlls_Memory_Usage.csv" ), 'wb')
		writer = csv.writer(csvfile)
		writer.writerow(['''"X" is the same memory allocated by logA and logB, the same callstack, the same count ,and the same size'''])
		writer.writerow(['Dll', 'DeltaUsage'+self._config.unit(), "UsageLogA"+self._config.unit()+"-X", "usage_logB"+self._config.unit()+"-X"])

		for app_dll in dlls:
			results.append( self.query(app_dll))
			print 'Process Done: %s.dll' % app_dll

		results.sort( key = lambda x:x['delta_usage'],reverse = True ) 

		delta_Usage = 0
		usageLogA = 0
		usageLogB = 0
		for data in results:	
			delta_Usage = data['usage_logA']
			usageLogA = data['usage_logB']
			usageLogB += data['delta_usage']

		print 'delta_Usage:',self._config.number_in_unit( delta_Usage )
		print 'Usage_logA:',self._config.number_in_unit( usageLogA )
		print 'Usage_logB:',self._config.number_in_unit( usageLogB )

		for data in results:	
			print '-'*30
			print 'Name: ',data['name']
			print "Delta Usage: "+self._config.unit()+" :", self._config.number_in_unit( data['delta_usage'] )    
			print '\n'
			writer.writerow(( 
				data['name'],
				self._config.number_in_unit( data['delta_usage'] ),
				str( self._config.number_in_unit( data['usage_logA'] )),
				str(self._config.number_in_unit( data['usage_logB'] ))
				));

		csvfile.close()

#analyse = Analyse("data.txt")
#analyse.parseFile()
#analyse.showDlls()

#analyse.queryAll()

#analyse.printDll( 'GSCParasolidKernel'  )
#analyse.printDll( 'Display3DDataManagerComponent'  )
#analyse.printDllByLine("Display3DDataManagerComponent")
#analyse.printDllByLine("Gfx")
#analyse.printDllByLine("DisplayManager")
#print analyse.query('Repository')


def main( data_file, config ):
	analyse = Analyse(data_file, config )
	analyse.parseFile()
	while True:
		print "\n"
		print "\n"
		print "\n"
		print "[1] listDlls"
		print "[2] appliction usage"
		print "[3] dll usage [callstack]"
		print "[4] dll usage [file, line]"
		print "[5] check the result"
		print "[6] Exit"
		choice = raw_input("Input your choice: ")
		if choice == "1":
			analyse.listDlls()
			print '\n'
			raw_input("Command Finish,Press enter key to continue...")
		elif choice == "2":
			analyse.queryAll()
			print '\n'
			raw_input("Command Finish,Press enter key to continue...")
		elif choice == "3":
			comp_name = raw_input("Input the dll name: ")
			analyse.printDll(comp_name)
			print '\n'
			raw_input("Command Finish,Press enter key to continue...")
		elif choice == "4":
			comp_name = raw_input("Input the dll name: ")
			analyse.printDllByLine(comp_name)
			print '\n'
			raw_input("Command Finish,Press enter key to continue...")
		elif choice == "5":
			target_path = '.'
			if os.path.exists( analyse.getOutputFolder() ):
				target_path = analyse.getOutputFolder() 
			os.system("explorer "+os.path.abspath(target_path))
		elif choice == "6":
			break;

#analyse = Analyse("10k_importMesh_10kmesh.mem")
#analyse.parseFile()
#analyse.listDlls()

#analyse.queryAll()

#analyse.printDll( 'GSCParasolidKernel'  )
#analyse.printDll( 'Display3DDataManagerComponent'  )
#analyse.printDllByLine("Display3DDataManagerComponent")
#analyse.printDllByLine("Gfx")
#analyse.printDllByLine("DisplayManager")
#print analyse.query('Repository')


if __name__ == "__main__":
	if len( sys.argv ) == 2:
	 	base = raw_input('Input the base of data (10 or 16) :')
		if base != "10" and base != "16":
			raise NotImplementedError
		base = int( base, 10 )

		unit = raw_input("Input the unit your like ('G' or 'M' or 'K' or 'B') :")
		if unit.upper() not in ('G','M','K','B'):
			raise NotImplementedError
		config = Config( base, unit )
		main( sys.argv[1] , config )
	else:
		print "Invalid syntax."
		print "Usage: analyse DATA_FILE_NAME"
