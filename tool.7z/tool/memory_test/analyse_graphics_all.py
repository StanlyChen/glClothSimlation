import sys
sys.dont_write_bytecode = True

import os
import analyse

if __name__ == "__main__":
	config = analyse.Config( 10, 'M' )
	file_count = 0
	for file_name in os.listdir("."):
		if file_name.endswith('.mem'):
			print "Start File: ", file_name
			data_analyse = analyse.Analyse(file_name, config )
			data_analyse.parseFile()
			data_analyse.listDlls()
			data_analyse.queryAll()
			for comp in ['Gfx','DisplayManager','Display3DDataManagerComponent']:
				data_analyse.printDll(comp)
				data_analyse.printDllByLine( comp )
			print 'Finish File: ', file_name 
			file_count+=1

	print "Done, total %d files" % file_count



