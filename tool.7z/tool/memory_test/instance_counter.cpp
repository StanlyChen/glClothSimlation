#include "instance_counter.h"

tbb::critical_section  InstanceCounter::s_counterLock;
std::map<std::string, std::pair<unsigned int, unsigned int>>  InstanceCounter::s_countermap;
std::vector<std::string> InstanceCounter::s_messages;

void InstanceCounter::report(const std::string filename )
{
    tbb::critical_section::scoped_lock scope(s_counterLock);
    std::stringstream sstring;

    sstring << "Cls" << "," << "SizeOf(Cls)" << "," << "Instance Count" << "," << "SizeOf(Cls)*Count" << std::endl;
    for (auto iter : s_countermap)
    {
        sstring << iter.first << "," << iter.second.first << "," << iter.second.second << "," << iter.second.first*iter.second.second << std::endl;
    }

    std::ofstream outfile(filename);
    std::string tmpline;
    while (std::getline(sstring, tmpline))
    {
        outfile << tmpline << std::endl;
    }

    outfile << std::endl << std::endl;
    outfile << "Messages" << std::endl;
    

    for( std::string msg : s_messages )
    {
        outfile << msg << std::endl;
    }

    outfile.close();
}


InstanceCounter::InstanceCounter(std::string className, unsigned int classSize, std::function<std::string()> msg_fun)
{
    m_className = className;
    {
        tbb::critical_section::scoped_lock scope(s_counterLock);
        auto iter = s_countermap.find(className);
        if (iter == s_countermap.end())
        {
            s_countermap.insert(std::make_pair(className, std::make_pair(classSize - sizeof(InstanceCounter), 0)));
            std::string msg = msg_fun();
            if (""!= msg)
            {
                s_messages.push_back(msg);
            }
            iter = s_countermap.find(className);
        }
        iter->second.second += 1;
    }

}

InstanceCounter::~InstanceCounter()
{
    {
        tbb::critical_section::scoped_lock scope(s_counterLock);
        auto iter = s_countermap.find(m_className);
        iter->second.second -= 1;
    }
}