#ifndef INSTANCE_COUNTER_H
#define INSTANCE_COUNTER_H
#include "tbb.h"
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <SCA\SCA.h>
#include <functional>

class InstanceCounter
{
public:
    InstanceCounter(std::string className, unsigned int classSize, std::function<std::string()> msg_fun = InstanceCounter::emptyMsg);

    virtual ~InstanceCounter();

private:
    static tbb::critical_section  s_counterLock;
    static std::map<std::string, std::pair<unsigned int, unsigned int>>  s_countermap;
    static std::vector<std::string> InstanceCounter::s_messages;
    static std::string emptyMsg() { return std::string(); }
    std::string m_className;

public:
    static void report( const std::string filename );
};

#define INSTANCE_COUNT(clsName) InstanceCounter __count{#clsName,sizeof(clsName)};
#define INSTANCE_COUNT_WITH_MSG(clsName, msgFuc) InstanceCounter __count{#clsName,sizeof(clsName),msgFuc};
#endif#pragma once
